import games.game_exodus, games.game_prime

def prime():
    games.game_prime.prime()