import cli

def winning():
    print(f'Congratulations, {cli.nickname}!')

def defeat():
    print(f'Let\'s try again, {cli.nickname}!')