import games.game_exodus, games.game_even


def even():
    games.game_even.even()