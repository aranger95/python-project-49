import games.game_exodus, games.game_calc


def calc():
    games.game_calc.calc()