import games.game_exodus, games.game_progression


def progression():
    games.game_progression.progression()