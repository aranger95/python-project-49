import games.game_exodus, games.game_gcd

def gcd():
    games.game_gcd.gcd()