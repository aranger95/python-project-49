### Hexlet tests and linter status:
[![Actions Status](https://github.com/aranger95/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/aranger95/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b3cbad7cefe23fb632f3/maintainability)](https://codeclimate.com/github/aranger95/python-project-49/maintainability)
